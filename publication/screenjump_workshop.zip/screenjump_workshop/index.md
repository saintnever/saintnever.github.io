---
title: "ScreenJump: An AR-facilitated User-centric Interaction System for Fine-grained Resource Manipulation Across Displays"
authors:
- Xin Zeng*
- Xinyi Yang*
- __Tengxiang Zhang__
- Yukang Yan
- Yiqiang Chen

date: "2021-03-11T00:00:00Z"
doi: ''

# Schedule page publish date (NOT publication's date).
publishDate: "2023-06-01T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["3"]

# Publication name and optional abbreviated publication name.
publication: In *Adjunct Proceedings of the 2021 CHI Conference on Human Factors in Computing Systems*. 
publication_short: In *Workshop on User Experience for Multi-Device':' Ecosystems Challenges and Opportunities*.<br/><font color="grey"> AR-facilitated cross-display resource manipulation.</font>

abstract: There is an increasing demand for remote manipulation of digital resources across different computers. In this paper, we propose ScreenJump, an AR-facilitated cross-device interaction system that enables user-centric, fine-grained resource manipulation across computer displays. Each computer encodes the identity information into screen blinks that can be detected by cameras but are invisible to human eyes. The AR headset with cameras then localizes surrounding displays and connects with the corresponding computers. The relative positions of fine-grained resources (e.g. pictures, text paragraphs, UI elements) within each display are calculated and shared with the AR headset. Users can then select and manipulate such resources by performing in-air gestures. We explain the system design and implementation in detail, as well as three application use cases that potentially benefit from ScreenJump.
# Summary. An optional shortened abstract.
summary:  <font color="#953100"><b>UX4MDE CHI'21 Workshop. On going effort.</b></font> </br>AR-facilitated cross-display resource manipulation.

tags:
- AR 
- cross-device interaction 
- screen-camera communication
featured: false


#links:
#- name: Custom Link
#  url: http://example.org
url_pdf: 'publication/screenjump_workshop/CHI21_workshop.pdf'
url_slides: '' 
#publication/screenjump_workshop20/CHI2021_workshop.pdf
url_code: ''
url_dataset: ''
url_poster: ''
url_project: ''
url_source: ''
url_video: ''

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: ''
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: [links]

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---

<!-- {{% alert note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /alert %}}

{{% alert note %}}
Click the *Slides* button above to demo Academic's Markdown slides feature.
{{% /alert %}} -->

<!-- Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/). -->
